// Local UI integration using five fake CLI processes; no model calls.
const { chromium } = require('playwright');
const { execFileSync, execFile } = require('node:child_process');
const { promisify } = require('node:util');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const assert = require('node:assert/strict');
const run = promisify(execFile);
const python = process.env.PYTHON || 'python3';
const scripts = path.resolve(__dirname, '../scripts');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-meet-group-ui-'));
const room = path.join(root, '五角色.sqlite');
function args(script, action, rest) {
  return [path.join(scripts, script), action, '--room', room, ...rest];
}
function command(script, action, ...rest) {
  return JSON.parse(execFileSync(python, args(script, action, rest), { encoding: 'utf8' }));
}
async function round(id, ...rest) {
  return JSON.parse(
    (
      await run(python, args('group.py', 'round', ['--request-id', id, ...rest]), {
        encoding: 'utf8',
      })
    ).stdout,
  );
}
let browser;
(async () => {
  const cli = path.join(root, 'fake claude');
  execFileSync(python, [
    '-c',
    'import sys;from pathlib import Path;sys.path.insert(0,sys.argv[1]);from test_group import FAKE_ROLE;p=Path(sys.argv[2]);p.write_text(FAKE_ROLE.replace("time.sleep(1)","time.sleep(2)"));p.chmod(0o755)',
    __dirname,
    cli,
  ]);
  const roles = JSON.parse(fs.readFileSync(path.join(scripts, '../examples/roles.json'), 'utf8'));
  roles.forEach((role) => {
    role.cli = cli;
    fs.writeFileSync(path.join(root, 'mode-' + role.id + '.txt'), 'slow');
  });
  const roleFile = path.join(root, 'roles.json');
  fs.writeFileSync(roleFile, JSON.stringify(roles));
  const brief = {
    question: '演示：五个角色评审 Agent 协作方案',
    goal: '从产品、技术、使用体验和业务目标评估第一版范围。',
    current_view: '保留原 Codex 长期上下文，邀请五个独立角色交叉评审，讨论最多 **2 轮**。',
    constraints: ['本次仅讨论，不修改业务代码'],
    decisions: ['当前 Codex 担任主持人'],
    rejected_options: [],
    code_references: [],
    unknowns: ['用户角色为模拟视角，真实用户反馈待验证'],
  };
  const briefFile = path.join(root, 'brief.json');
  fs.writeFileSync(briefFile, JSON.stringify(brief));
  command(
    'group.py',
    'init',
    '--cwd',
    root,
    '--briefing-file',
    briefFile,
    '--roles-file',
    roleFile,
    '--rounds',
    '2',
  );
  const started = command('view.py', 'start');
  browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM || '/usr/bin/chromium',
    args: ['--no-sandbox'],
  });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1080 },
    acceptDownloads: true,
  });
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto(started.url);
  await page.waitForSelector('#event-1');
  assert.match(await page.locator('#participant-count').innerText(), /06 PARTICIPANTS/);
  assert.equal(await page.locator('.role-card').count(), 6);
  for (const role of roles)
    assert.match(await page.locator('#roles-list').innerText(), new RegExp(role.title));
  const pending = round('first');
  await page.waitForFunction(() =>
    document.getElementById('roles-list').textContent.includes('回复中'),
  );
  assert.equal((await pending).status.completed_rounds, 1);
  await page.waitForSelector('#event-6');
  assert.equal(await page.locator('.message').count(), 6);
  assert.match(await page.locator('#event-2 .role').innerText(), /Claude/);
  await page.locator('#collapse-all').click();
  assert.equal(await page.locator('#event-2 .message-body').isVisible(), false);
  command(
    'chat.py',
    'send',
    '--as',
    'codex',
    '--request-id',
    'host-second',
    '--text',
    '## 第二轮\n请回应其他角色的不同意见，并说明哪些问题还缺少证据。',
  );
  const second = await round('second');
  assert.equal(second.status.completed_rounds, 2);
  await page.waitForSelector('#event-12');
  assert.equal(await page.locator('.round-divider').count(), 2);
  assert.match(await page.locator('#round-progress').innerText(), /2 \/ 2 轮/);
  assert.equal(await page.locator('#event-2 .message-body').isVisible(), false);
  await page.locator('#expand-all').click();
  const proposal = {
    summary: '保留原主持人上下文，采用 **独立角色 + 有限轮次** 的讨论方式。',
    agreements: ['公开展示各角色的实际发言', '结论需要全体角色审核'],
    disagreements: ['允许保留尚未解决的不同判断'],
    open_questions: ['真实用户反馈和真实模型联调'],
    evidence_message_ids: Array.from({ length: 12 }, (_, i) => i + 1),
  };
  const proposalFile = path.join(root, 'proposal.json');
  fs.writeFileSync(proposalFile, JSON.stringify(proposal));
  const assessmentFile = path.join(root, 'assessment.json');
  function assess(id) {
    fs.writeFileSync(
      assessmentFile,
      JSON.stringify({
        decision: 'conclude',
        reason: '已收齐角色意见，保留不确定性，可交全体审核',
        blocking_questions: [],
        accepted_uncertainties: ['真实模型与用户反馈待验证'],
        next_steps: [],
        evidence_message_ids: proposal.evidence_message_ids,
      }),
    );
    command('chat.py', 'assess', '--as', 'codex', '--request-id', id, '--file', assessmentFile);
  }
  const originalSessions = Object.fromEntries(
    roles.map((role) => [
      role.id,
      JSON.parse(fs.readFileSync(room + '.peers/' + role.id + '/status.json', 'utf8'))
        .native_session_id,
    ]),
  );
  fs.writeFileSync(
    assessmentFile,
    JSON.stringify({
      decision: 'continue',
      reason: '验收边界仍缺少证据，建议用户确认后追加一轮交叉检查。',
      blocking_questions: ['失败时是否仍满足业务验收标准？'],
      accepted_uncertainties: ['真实用户反馈仍未收集'],
      next_steps: ['请各角色针对验收边界提出可验证条件'],
      evidence_message_ids: proposal.evidence_message_ids,
    }),
  );
  command(
    'chat.py',
    'assess',
    '--as',
    'codex',
    '--request-id',
    'needs-more',
    '--file',
    assessmentFile,
  );
  await page.waitForFunction(() =>
    document.getElementById('assessment').textContent.includes('建议继续讨论'),
  );
  assert.match(await page.locator('#activity').innerText(), /等待用户决定/);
  assert.equal(command('group.py', 'status').status.completed_rounds, 2);
  if (process.argv[2])
    await page.screenshot({ path: path.resolve(process.argv[2]), fullPage: true });
  command(
    'chat.py',
    'extend',
    '--as',
    'codex',
    '--request-id',
    'user-approved-more',
    '--rounds',
    '1',
    '--reason',
    '用户确认再讨论一轮，继续核对验收边界',
  );
  await page.waitForSelector('.message.extension');
  assert.match(await page.locator('#assessment').innerText(), /已继续原讨论/);
  command(
    'chat.py',
    'send',
    '--as',
    'codex',
    '--request-id',
    'host-third',
    '--text',
    '继续原讨论。请结合已有角色意见，补齐验收边界的证据和可验证条件。',
  );
  const continued = await round('continued-third');
  assert.equal(continued.status.completed_rounds, 3);
  await page.waitForFunction(() =>
    document.getElementById('round-progress').textContent.includes('3 / 3 轮'),
  );
  for (const role of roles) {
    const calls = fs
      .readFileSync(path.join(root, 'calls-' + role.id + '.jsonl'), 'utf8')
      .trim()
      .split('\n')
      .map(JSON.parse);
    assert.equal(calls.length, 3);
    const argv = calls.at(-1).argv;
    assert.equal(argv[argv.indexOf('--resume') + 1], originalSessions[role.id]);
  }
  const taskFile = path.join(root, 'task.json');
  fs.writeFileSync(taskFile, JSON.stringify({
    title: '核对验收条件', instructions: '汇总 **验收证据**。', context: '来自同一房间的第三轮。',
    constraints: ['只读检查'], acceptance_criteria: ['引用会议证据'],
  }));
  function meetingArgs(id) {
    return ['--as', 'codex', '--task-id', 'verify', '--request-id', id];
  }
  const assignment = command('meeting.py', 'assign', ...meetingArgs('assign'), '--type', 'readonly',
    '--to', roles[0].id, '--file', taskFile, '--evidence-event', '1');
  await page.waitForSelector('#work-panel');
  assert.match(await page.locator('#work-list').innerText(), /核对验收条件[\s\S]*待执行/);
  await page.waitForSelector('#event-' + assignment.event.id + ' strong');
  const taskRun = run(python, args('meeting.py', 'run', meetingArgs('run')), { encoding: 'utf8' });
  await page.waitForFunction(() => document.getElementById('work-list').textContent.includes('执行中'));
  const workResult = JSON.parse((await taskRun).stdout).event;
  await page.waitForFunction(() => document.getElementById('work-list').textContent.includes('待验收'));
  assert.equal(await page.locator('#work-list a').getAttribute('href'), '#event-' + workResult.id);
  const reviewFile = path.join(root, 'task-review.md');
  fs.writeFileSync(reviewFile, '已检查依据。');
  command('meeting.py', 'review', ...meetingArgs('accept'), '--decision', 'accept', '--text-file', reviewFile,
    '--result', String(workResult.id));
  await page.waitForFunction(() => document.getElementById('work-list').textContent.includes('已验收'));
  proposal.evidence_message_ids = command('chat.py', 'read', '--as', 'codex')
    .events.filter((event) => event.kind === 'message')
    .map((event) => event.id);
  fs.writeFileSync(proposalFile, JSON.stringify(proposal));
  assess('ready-one');
  command(
    'chat.py',
    'propose',
    '--as',
    'codex',
    '--request-id',
    'proposal-one',
    '--file',
    proposalFile,
  );
  await round('review-one', '--only', roles[0].id);
  await page.waitForFunction(() =>
    document.getElementById('outcome').textContent.includes('已审核 1 / 5'),
  );
  assert.match(await page.locator('#outcome').innerText(), /等待全体审核/);
  fs.writeFileSync(path.join(root, 'mode-' + roles[4].id + '.txt'), 'reject');
  const disputed = await round('review-rest');
  assert.equal(disputed.status.conclusion_status, 'disputed');
  await page.waitForFunction(() =>
    document.getElementById('outcome').textContent.includes('有角色异议'),
  );
  assert.notEqual(await page.locator('#phase').innerText(), '已确认记录');
  fs.writeFileSync(path.join(root, 'mode-' + roles[4].id + '.txt'), 'ok');
  assess('ready-revision');
  command(
    'chat.py',
    'propose',
    '--as',
    'codex',
    '--request-id',
    'proposal-two',
    '--file',
    proposalFile,
  );
  const confirmed = await round('review-revision');
  assert.equal(confirmed.status.conclusion_status, 'confirmed');
  assert.equal(confirmed.status.phase, 'finalizing');
  await page.waitForFunction(
    () => document.getElementById('phase').textContent === '待整理最终结论',
  );
  assert.match(await page.locator('#outcome').innerText(), /等待主持人整理/);
  const finalFile = path.join(root, 'final.json');
  const finalBody = {
    proposal_id: confirmed.status.latest_proposal.id,
    review_ids: confirmed.status.reviews.map((r) => r.id),
    change_type: 'none',
    conclusion: confirmed.status.latest_proposal.body,
    resolutions: confirmed.status.reviews.map((r) => ({
      review_id: r.id,
      point: r.body.comment,
      disposition: 'already_covered',
      resolution: '逐角色核对审核意见，原稿已记录各角色观点，无需改动。',
    })),
  };
  fs.writeFileSync(finalFile, JSON.stringify(finalBody));
  command(
    'chat.py',
    'finalize',
    '--as',
    'codex',
    '--request-id',
    'final-group',
    '--file',
    finalFile,
  );

  await page.waitForFunction(() =>
    document.getElementById('outcome').textContent.includes('最终结论 · 已处理最后审核意见'),
  );
  const downloadPromise = page.waitForEvent('download');
  await page.locator('#export').click();
  const download = await downloadPromise;
  const report = fs.readFileSync(await download.path(), 'utf8');
  assert.match(report, /全部角色已确认记录/);
  assert.match(report, /最后审核意见处理/);
  assert.equal(finalBody.resolutions.length, 5);
  assert.match(report, /轮次：3 \/ 3 轮完成/);
  assert.match(report, /续聊次数：1/);
  roles.forEach((role) => assert.ok(report.includes(role.title)));
  const response = await page.evaluate(async () =>
    (
      await fetch('/api/state', {
        headers: { Authorization: 'Bearer ' + sessionStorage.getItem('agent-chat-token') },
      })
    ).json(),
  );
  assert.ok(!JSON.stringify(response).includes('native_session_id'));
  assert.ok(!JSON.stringify(response).includes(cli));
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  assert.deepEqual(errors, []);
  console.log(
    'Group browser checks passed: all-role finalization, readiness, user-approved continuation reuses five original sessions, rounds, fold persistence, all-role reviews, export, privacy and mobile. Fake CLIs only.',
  );
})()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      command('chat.py', 'stop', '--reason', 'test cleanup');
      command('view.py', 'close');
    } catch (_) {}
    if (browser) await browser.close();
    fs.rmSync(root, { recursive: true, force: true });
  });
